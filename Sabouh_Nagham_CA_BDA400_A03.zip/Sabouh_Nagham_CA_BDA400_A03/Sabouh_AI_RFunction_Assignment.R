# AI Assistance Declaration
# ChatGPT (GPT-6), 2026-10-31, assisted with example code design, documentation, prompt drafts, and reflection draft.
# Prompt record: see AI_Prompts_Appendix.md. RStudio testing and independent user validation are NOT yet complete.
# Final calculations must be executed and verified by the student.

# Original task: Remove IQR-based outliers from a numeric vector while retaining missing values only when requested.
# Source: synthetic data only; no private data.

# AI-assisted INITIAL function (illustrates a limitation: no input validation or NA handling):
remove_outliers_initial <- function(x) {
  q <- quantile(x, c(0.25, 0.75))  # Obtain quartiles (fails with NA by default).
  spread <- IQR(x)                 # Compute interquartile range.
  x[x >= q[1] - 1.5 * spread & x <= q[2] + 1.5 * spread] # Filter values.
}

# REVISED function: verify this code and any outputs yourself in RStudio.
remove_outliers <- function(x, na_action = "omit") {
  if (!is.numeric(x) || !is.atomic(x)) {  # Reject nonnumeric inputs.
    stop("x must be a numeric vector")   # Explain invalid input.
  }
  if (length(na_action) != 1L || is.na(na_action) ||
      !na_action %in% c("omit", "keep")) { # Check accepted NA mode.
    stop("na_action must be 'omit' or 'keep'")
  }
  finite_values <- x[is.finite(x)]          # Quartiles use only finite values.
  if (length(finite_values) == 0L) {        # Handle empty/all-missing inputs.
    if (na_action == "keep") return(x[is.na(x)])
    return(numeric(0))
  }
  bounds <- quantile(finite_values, probs = c(.25, .75), names = FALSE) # Q1,Q3.
  iqr <- bounds[2] - bounds[1]             # Quartile spread.
  low <- bounds[1] - 1.5 * iqr              # Lower fence.
  high <- bounds[2] + 1.5 * iqr             # Upper fence.
  retained <- is.finite(x) & x >= low & x <= high # Non-outlier values.
  if (na_action == "keep") retained <- retained | is.na(x) # Preserve NA/NaN.
  x[retained]                               # Return values in original order.
}
