# AI Assistance Declaration: ChatGPT (GPT-6), 2026-10-31 assisted with test design.
# Student must execute and independently verify the tests and results.
source("Sabouh_AI_RFunction_Assignment.R")

check <- function(label, actual, expected) {
  result <- identical(actual, expected)
  cat(label, if (result) "PASS" else "FAIL", "\n")
  if (!result) { print(actual); print(expected) }
  stopifnot(result)
}

# Known synthetic example: values within fences are retained.
check("standard outlier", remove_outliers(c(10, 15, 999, 20, 25)), c(10, 15, 20, 25))
check("missing omitted", remove_outliers(c(10, NA_real_, 12, 11)), c(10, 12, 11))
check("missing preserved", remove_outliers(c(10, NA_real_, 12, 11), "keep"), c(10, NA_real_, 12, 11))
check("constant vector", remove_outliers(c(5, 5, 5)), c(5, 5, 5))
check("empty vector", remove_outliers(numeric(0)), numeric(0))
check("infinite removed", remove_outliers(c(1, 2, Inf, 3)), c(1, 2, 3))
# Independent method: compare cleaned values to base R's boxplot.stats() for this data.
x <- c(10, 15, 999, 20, 25)
independent <- x[!(x %in% boxplot.stats(x)$out)]
check("independent boxplot.stats comparison", remove_outliers(x), independent)
cat("ALL TESTS FINISHED; review results and retain actual console log/screenshot.\n")
