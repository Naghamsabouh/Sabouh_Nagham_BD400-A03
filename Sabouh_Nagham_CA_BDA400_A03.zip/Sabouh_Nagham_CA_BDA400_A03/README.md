# BDA400 Assignment 3 — Prompting R Functions with AI
**Student:** Nagham Sabouh

## Files
- `Sabouh_AI_RFunction_Assignment.R`: original task, initial and revised R functions with comments.
- `Run_Tests.R`: synthetic-data test cases and an independent base-R cross-check.
- `Sabouh_Reflection.docx`: 150–200 word reflection draft; requires student review.
- `AI_Prompts_Appendix.md`: AI assistance record and prompts.

## How to run
1. Install R and RStudio. Open the folder as the working directory in RStudio.
2. Source `Sabouh_AI_RFunction_Assignment.R`, then run `Run_Tests.R`.
3. Inspect results; fix any errors and record what you changed.
4. Save actual console output or a screenshot from RStudio, and include it with the submission.
5. Conduct the independent check yourself (the instructor also specifies a primary Sheets calculation and a spot-check).
6. Revise the reflection so it describes what you personally observed.

## Submission note
**Not yet independently verified.** Do not claim the test script ran until it has actually run in RStudio.
