# AI Assistance Declaration
ChatGPT (GPT-6) was used on October 31, 2026 to prepare an example R function, a revision, testing suggestions, documentation, and a draft reflection. Prompts and outputs below document this AI-assisted draft. The student must run, evaluate, revise, and verify every final result.

# AI Prompts and Key Responses — example development record

1. **Seed prompt (prepared as the task specification):** “Write an R function that removes outliers from a numeric vector using the 1.5 × IQR rule.”
   **Key response:** `remove_outliers_initial()` uses `quantile()`, `IQR()`, and logical filtering.
2. **Refinement prompt (prepared):** “Revise the function to include comments, argument validation, support for NA values, and a clean result.”
   **Key response:** `remove_outliers()` checks numeric input, offers `na_action`, handles empty vectors, and excludes infinity.
3. **Explanation prompt (prepared):** “Explain what each line of the R code does and how I might test it.”
   **Key response:** Each step in the revised function has in-code comments; `Run_Tests.R` demonstrates cases.
4. **Debug prompt (prepared; not evidence of a real error encounter):** “Update the function to handle NA values and an empty numeric vector.”
   **Key response:** Add finite-value screening and a zero-length case.
5. **Edge-case prompt (prepared):** “How could I test the function with outliers, missing values, constant values, infinite values, and an independent base-R check?”
   **Key response:** Suggested tests included in `Run_Tests.R`.

**Important:** This file documents AI-assisted generation in this chat, not a claim that the student personally submitted each prompt or performed the tests. Record any real follow-up prompts and real debugging results here after RStudio work. Do not state that verification is complete until it is.
